package com.campaignx.campaignx_agent.service;

import com.campaignx.campaignx_agent.model.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Value;

import java.util.*;



@Service
public class LLMService {

    @Value("${openrouter.api.key}")
    private String apiKey;

    @Value("${openrouter.api.url}")
    private String apiUrl;

    @Value("${openrouter.model}")
    private String model;

    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${openrouter.api.key}")
    private String openRouterApiKey;

    @Value("${openrouter.api.url}")
    private String openRouterUrl;

    @Value("${openrouter.model}")
    private String openRouterModel;


    public String callLLM(String prompt) {

        int maxRetries = 3;

        for(int attempt = 1; attempt <= maxRetries; attempt++) {

            try {

                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                headers.setBearerAuth(openRouterApiKey);

                Map<String,Object> body = new HashMap<>();

                body.put("model", openRouterModel);

                List<Map<String,String>> messages = new ArrayList<>();

                Map<String,String> msg = new HashMap<>();
                msg.put("role", "user");
                msg.put("content", prompt);

                messages.add(msg);

                body.put("messages", messages);
                body.put("temperature", 0.7);
                body.put("max_tokens", 300);

                HttpEntity<Map<String,Object>> request =
                        new HttpEntity<>(body, headers);

                ResponseEntity<Map> response =
                        restTemplate.postForEntity(openRouterUrl, request, Map.class);

                Map result = response.getBody();

                List choices = (List) result.get("choices");
                Map choice = (Map) choices.get(0);
                Map message = (Map) choice.get("message");

                return message.get("content").toString();

            } catch(Exception e) {

                System.out.println("⚠ LLM call failed attempt " + attempt);

                try { Thread.sleep(1500); } catch(Exception ex){}
            }
        }

        // ⭐ FINAL FALLBACK RESPONSE
        System.out.println("🚨 LLM completely failed → using fallback content");

        return """
    {
      "subject": "Special Offer for Valued Customers",
      "body": "Dear Customer, explore our new financial product designed to maximize your returns. Click below to learn more."
    }
    """;
    }


    public Strategy interpretBrief(String brief) {

        String prompt = """
You are an AI banking marketing strategist.

Extract realistic customer targeting filters from campaign brief.

IMPORTANT DATA RULES:
- Premium / Elite / Luxury → minCreditScore = 680
- Good credit → minCreditScore = 620
- High income / affluent → minIncome = 150000
- Moderate income → minIncome = 80000
- Women / female → gender = Female
- Men / male → gender = Male
- Senior citizens → age > 50 (ignore if age not supported)
- City mentioned → set city
- If not clearly implied → return null

Return ONLY valid JSON.

FORMAT:

{
 "city": "string or null",
 "gender": "string or null",
 "minIncome": number or null,
 "minCreditScore": number or null
}

Campaign Brief:
""" + brief;

        String response = callLLM(prompt);

        Strategy strategy = new Strategy();

        try {

            ObjectMapper mapper = new ObjectMapper();

            int start = response.indexOf("{");
            int end = response.lastIndexOf("}") + 1;
            String json = response.substring(start, end);

            Map<String,Object> result =
                    mapper.readValue(json, Map.class);

            // CITY
            Object cityObj = result.get("city");
            if(cityObj instanceof String)
                strategy.setCity((String) cityObj);
            else if(cityObj instanceof List && !((List<?>) cityObj).isEmpty())
                strategy.setCity(((List<?>) cityObj).get(0).toString());

            // GENDER
            Object genderObj = result.get("gender");
            if(genderObj instanceof String)
                strategy.setGender((String) genderObj);
            else if(genderObj instanceof List && !((List<?>) genderObj).isEmpty())
                strategy.setGender(((List<?>) genderObj).get(0).toString());

            // CREDIT SCORE
            if(result.get("minCreditScore") != null)
                strategy.setMinCreditScore(
                        ((Number) result.get("minCreditScore")).intValue()
                );

            // INCOME
            if(result.get("minIncome") != null)
                strategy.setMinIncome(
                        ((Number) result.get("minIncome")).intValue()
                );

        } catch(Exception e) {
            System.out.println("LLM parse failed → fallback strategy");
        }

        return strategy;
    }

    public EmailContent generateEmail(String brief, Strategy strategy) {

        String prompt = """
You are an expert financial marketing copywriter AI.

Write a persuasive, medium-length professional email.

Rules:
- Premium banking tone
- Clear benefits
- Strong call-to-action
- Not too long (120–180 words)
- Not generic
- Personalized to target segment

Return ONLY valid JSON.

FORMAT:

{
 "subject": "short premium catchy subject",
 "body": "professional marketing email"
}

Campaign Context:
""" + brief + """

Target Segment Insight:
City: """ + strategy.getCity() + """
Gender: """ + strategy.getGender() + """
Income Segment: """ + strategy.getMinIncome() + """
Credit Segment: """ + strategy.getMinCreditScore();
        String response = callLLM(prompt);

        EmailContent email = new EmailContent();

        try {

            ObjectMapper mapper = new ObjectMapper();

            // extract JSON safely
            int start = response.indexOf("{");
            int end = response.lastIndexOf("}");

            if(start != -1 && end != -1 && end > start){

                String json = response.substring(start, end + 1);

                Map<String,Object> map =
                        mapper.readValue(json, Map.class);

                if(map.get("subject") != null)
                    email.setSubject(map.get("subject").toString());

                if(map.get("body") != null)
                    email.setBody(map.get("body").toString());
            }
            // ⭐ IF STILL EMPTY → USE RAW LLM TEXT AS BODY
            if(email.getBody() == null){

                email.setSubject("AI Generated Campaign");
                email.setBody(response);
            }

        }
        catch(Exception e){

            System.out.println("⚠ Email JSON parse error → using raw LLM text");

            email.setSubject("AI Generated Campaign");
            email.setBody(response);
        }

        return email;
    }



    public String optimizeCampaign(CampaignMetrics metrics){

        String prompt = """
        A marketing campaign produced the following results:

        Open Rate: """ + metrics.getOpenRate() + """
        Click Rate: """ + metrics.getClickRate() + """

        Suggest improvements to increase engagement.
        """;

        return callLLM(prompt);
    }
}